onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /SerialFS_TB/GUT/N76
add wave -noupdate -divider GUT
add wave -noupdate /SerialFS_TB/N86
add wave -noupdate /SerialFS_TB/GUT/_382_
add wave -noupdate /SerialFS_TB/GUT/_198_
add wave -noupdate /SerialFS_TB/GUT/_222_
add wave -noupdate /SerialFS_TB/GUT/_262_
add wave -noupdate /SerialFS_TB/GUT/_435_
add wave -noupdate /SerialFS_TB/GUT/_263_
add wave -noupdate /SerialFS_TB/GUT/_261_
add wave -noupdate /SerialFS_TB/GUT/_264_
add wave -noupdate /SerialFS_TB/GUT/_276_
add wave -noupdate /SerialFS_TB/GUT/_277_
add wave -noupdate /SerialFS_TB/GUT/_260_
add wave -noupdate /SerialFS_TB/GUT/_278_
add wave -noupdate /SerialFS_TB/GUT/_246_
add wave -noupdate /SerialFS_TB/GUT/_205_
add wave -noupdate -divider FUT
add wave -noupdate /SerialFS_TB/FUT/_382_
add wave -noupdate /SerialFS_TB/FUT/_198_
add wave -noupdate /SerialFS_TB/FUT/_222_
add wave -noupdate /SerialFS_TB/FUT/_262_
add wave -noupdate /SerialFS_TB/FUT/_435_
add wave -noupdate /SerialFS_TB/FUT/_263_
add wave -noupdate /SerialFS_TB/FUT/_261_
add wave -noupdate /SerialFS_TB/FUT/_264_
add wave -noupdate /SerialFS_TB/FUT/_276_
add wave -noupdate /SerialFS_TB/FUT/_277_
add wave -noupdate /SerialFS_TB/FUT/_260_
add wave -noupdate /SerialFS_TB/FUT/_278_
add wave -noupdate /SerialFS_TB/FUT/_246_
add wave -noupdate /SerialFS_TB/FUT/_205_
add wave -noupdate /SerialFS_TB/GUT/_309_
add wave -noupdate /SerialFS_TB/GUT/_310_
add wave -noupdate /SerialFS_TB/GUT/_311_
add wave -noupdate /SerialFS_TB/FUT/_309_
add wave -noupdate /SerialFS_TB/FUT/_310_
add wave -noupdate /SerialFS_TB/FUT/_311_
add wave -noupdate /SerialFS_TB/i
add wave -noupdate /SerialFS_TB/TVnum
add wave -noupdate /SerialFS_TB/wireName
add wave -noupdate /SerialFS_TB/stuckAtVal
add wave -noupdate /SerialFS_TB/detected
add wave -noupdate /SerialFS_TB/FUT/N432
add wave -noupdate /SerialFS_TB/FUT/N431
add wave -noupdate /SerialFS_TB/FUT/N223
add wave -noupdate /SerialFS_TB/FUT/N329
add wave -noupdate /SerialFS_TB/FUT/N370
add wave -noupdate /SerialFS_TB/FUT/N421
add wave -noupdate /SerialFS_TB/FUT/N430
add wave -noupdate /SerialFS_TB/GUT/N432
add wave -noupdate /SerialFS_TB/GUT/N431
add wave -noupdate /SerialFS_TB/GUT/N223
add wave -noupdate /SerialFS_TB/GUT/N329
add wave -noupdate /SerialFS_TB/GUT/N370
add wave -noupdate /SerialFS_TB/GUT/N421
add wave -noupdate /SerialFS_TB/GUT/N430
add wave -noupdate /SerialFS_TB/detected
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {208683 ns} 0}
quietly wave cursor active 1
configure wave -namecolwidth 173
configure wave -valuecolwidth 143
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {208633 ns} {208778 ns}
