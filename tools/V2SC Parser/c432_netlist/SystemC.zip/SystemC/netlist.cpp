#include "netlist.h"
#include <cmath>

void c432_netlist::assignments()
{
	while (true)
	{
		N203.write(N223);
		N213.write(N223);
		N309.write(N329);
		N319.write(N329);
		N360.write(N370);
		_154_.write(N108);
		_270_.write(N102);
		_376_.write(N82);
		_398_.write(N76);
		_422_.write(N95);
		_155_.write(N89);
		_202_.write(N4);
		_224_.write(N1);
		_245_.write(N17);
		_271_.write(N11);
		_301_.write(N30);
		_322_.write(N43);
		_343_.write(N37);
		_353_.write(N24);
		_372_.write(N56);
		_373_.write(N69);
		_374_.write(N63);
		_375_.write(N50);
		N223.write(_377_);
		_378_.write(N112);
		_382_.write(N86);
		_387_.write(N99);
		_395_.write(N8);
		_402_.write(N21);
		_409_.write(N34);
		_414_.write(N47);
		_420_.write(N60);
		_427_.write(N73);
		N329.write(_433_);
		_436_.write(N115);
		_441_.write(N92);
		_156_.write(N105);
		_162_.write(N14);
		_167_.write(N27);
		_176_.write(N40);
		_182_.write(N53);
		_190_.write(N66);
		_196_.write(N79);
		N370.write(_205_);
		N421.write(_248_);
		N430.write(_253_);
		N431.write(_259_);
		N432.write(_265_);

		wait();
	}
}

void c17_netlist::GIC_Coverage_Calculator()
{
	totalObservedCombs =
	_447__Gate0->numOfObservedCombs +
	_448__Gate1->numOfObservedCombs +
	_449__Gate2->numOfObservedCombs +
	_450__Gate3->numOfObservedCombs +
	_451__Gate4->numOfObservedCombs +
	_452__Gate5->numOfObservedCombs +
	_453__Gate6->numOfObservedCombs +
	_454__Gate7->numOfObservedCombs +
	_455__Gate8->numOfObservedCombs +
	_456__Gate9->numOfObservedCombs +
	_457__Gate10->numOfObservedCombs +
	_458__Gate11->numOfObservedCombs +
	_459__Gate12->numOfObservedCombs +
	_460__Gate13->numOfObservedCombs +
	_461__Gate14->numOfObservedCombs +
	_462__Gate15->numOfObservedCombs +
	_463__Gate16->numOfObservedCombs +
	_464__Gate17->numOfObservedCombs +
	_465__Gate18->numOfObservedCombs +
	_466__Gate19->numOfObservedCombs +
	_467__Gate20->numOfObservedCombs +
	_468__Gate21->numOfObservedCombs +
	_469__Gate22->numOfObservedCombs +
	_470__Gate23->numOfObservedCombs +
	_471__Gate24->numOfObservedCombs +
	_472__Gate25->numOfObservedCombs +
	_473__Gate26->numOfObservedCombs +
	_474__Gate27->numOfObservedCombs +
	_475__Gate28->numOfObservedCombs +
	_476__Gate29->numOfObservedCombs +
	_477__Gate30->numOfObservedCombs +
	_478__Gate31->numOfObservedCombs +
	_479__Gate32->numOfObservedCombs +
	_480__Gate33->numOfObservedCombs +
	_481__Gate34->numOfObservedCombs +
	_482__Gate35->numOfObservedCombs +
	_483__Gate36->numOfObservedCombs +
	_484__Gate37->numOfObservedCombs +
	_485__Gate38->numOfObservedCombs +
	_486__Gate39->numOfObservedCombs +
	_487__Gate40->numOfObservedCombs +
	_488__Gate41->numOfObservedCombs +
	_489__Gate42->numOfObservedCombs +
	_490__Gate43->numOfObservedCombs +
	_491__Gate44->numOfObservedCombs +
	_492__Gate45->numOfObservedCombs +
	_493__Gate46->numOfObservedCombs +
	_494__Gate47->numOfObservedCombs +
	_495__Gate48->numOfObservedCombs +
	_496__Gate49->numOfObservedCombs +
	_497__Gate50->numOfObservedCombs +
	_498__Gate51->numOfObservedCombs +
	_499__Gate52->numOfObservedCombs +
	_500__Gate53->numOfObservedCombs +
	_501__Gate54->numOfObservedCombs +
	_502__Gate55->numOfObservedCombs +
	_503__Gate56->numOfObservedCombs +
	_504__Gate57->numOfObservedCombs +
	_505__Gate58->numOfObservedCombs +
	_506__Gate59->numOfObservedCombs +
	_507__Gate60->numOfObservedCombs +
	_508__Gate61->numOfObservedCombs +
	_509__Gate62->numOfObservedCombs +
	_510__Gate63->numOfObservedCombs +
	_511__Gate64->numOfObservedCombs +
	_512__Gate65->numOfObservedCombs +
	_513__Gate66->numOfObservedCombs +
	_514__Gate67->numOfObservedCombs +
	_515__Gate68->numOfObservedCombs +
	_516__Gate69->numOfObservedCombs +
	_517__Gate70->numOfObservedCombs +
	_518__Gate71->numOfObservedCombs +
	_519__Gate72->numOfObservedCombs +
	_520__Gate73->numOfObservedCombs +
	_521__Gate74->numOfObservedCombs +
	_522__Gate75->numOfObservedCombs +
	_523__Gate76->numOfObservedCombs +
	_524__Gate77->numOfObservedCombs +
	_525__Gate78->numOfObservedCombs +
	_526__Gate79->numOfObservedCombs +
	_527__Gate80->numOfObservedCombs +
	_528__Gate81->numOfObservedCombs +
	_529__Gate82->numOfObservedCombs +
	_530__Gate83->numOfObservedCombs +
	_531__Gate84->numOfObservedCombs +
	_532__Gate85->numOfObservedCombs +
	_533__Gate86->numOfObservedCombs +
	_534__Gate87->numOfObservedCombs +
	_535__Gate88->numOfObservedCombs +
	_536__Gate89->numOfObservedCombs +
	_537__Gate90->numOfObservedCombs +
	_538__Gate91->numOfObservedCombs +
	_539__Gate92->numOfObservedCombs +
	_540__Gate93->numOfObservedCombs +
	_541__Gate94->numOfObservedCombs +
	_542__Gate95->numOfObservedCombs +
	_543__Gate96->numOfObservedCombs +
	_544__Gate97->numOfObservedCombs +
	_545__Gate98->numOfObservedCombs +
	_546__Gate99->numOfObservedCombs +
	_547__Gate100->numOfObservedCombs +
	_548__Gate101->numOfObservedCombs +
	_549__Gate102->numOfObservedCombs +
	_550__Gate103->numOfObservedCombs +
	_551__Gate104->numOfObservedCombs +
	_552__Gate105->numOfObservedCombs +
	_553__Gate106->numOfObservedCombs +
	_554__Gate107->numOfObservedCombs +
	_555__Gate108->numOfObservedCombs +
	_556__Gate109->numOfObservedCombs +
	_557__Gate110->numOfObservedCombs +
	_558__Gate111->numOfObservedCombs +
	_559__Gate112->numOfObservedCombs +
	_560__Gate113->numOfObservedCombs +
	_561__Gate114->numOfObservedCombs +
	_562__Gate115->numOfObservedCombs +
	_563__Gate116->numOfObservedCombs +
	_564__Gate117->numOfObservedCombs +
	_565__Gate118->numOfObservedCombs +
	_566__Gate119->numOfObservedCombs +
	_567__Gate120->numOfObservedCombs +
	_568__Gate121->numOfObservedCombs +
	_569__Gate122->numOfObservedCombs +
	_570__Gate123->numOfObservedCombs +
	_571__Gate124->numOfObservedCombs +
	_572__Gate125->numOfObservedCombs +
	_573__Gate126->numOfObservedCombs +
	_574__Gate127->numOfObservedCombs +
	_575__Gate128->numOfObservedCombs +
	_576__Gate129->numOfObservedCombs +
	_577__Gate130->numOfObservedCombs +
	_578__Gate131->numOfObservedCombs +
	_579__Gate132->numOfObservedCombs +
	_580__Gate133->numOfObservedCombs +
	_581__Gate134->numOfObservedCombs +
	_582__Gate135->numOfObservedCombs +
	_583__Gate136->numOfObservedCombs +
	_584__Gate137->numOfObservedCombs +
	_585__Gate138->numOfObservedCombs +
	_586__Gate139->numOfObservedCombs +
	_587__Gate140->numOfObservedCombs +
	_588__Gate141->numOfObservedCombs +
	_589__Gate142->numOfObservedCombs +
	_590__Gate143->numOfObservedCombs +
	_591__Gate144->numOfObservedCombs +
	_592__Gate145->numOfObservedCombs +
	_593__Gate146->numOfObservedCombs +
	_594__Gate147->numOfObservedCombs +
	_595__Gate148->numOfObservedCombs +
	_596__Gate149->numOfObservedCombs +
	_597__Gate150->numOfObservedCombs +
	_598__Gate151->numOfObservedCombs +
	_599__Gate152->numOfObservedCombs +
	_600__Gate153->numOfObservedCombs +
	_601__Gate154->numOfObservedCombs +
	_602__Gate155->numOfObservedCombs +
	_603__Gate156->numOfObservedCombs +
	_604__Gate157->numOfObservedCombs +
	_605__Gate158->numOfObservedCombs +
	_606__Gate159->numOfObservedCombs +
	_607__Gate160->numOfObservedCombs +
	_608__Gate161->numOfObservedCombs +
	_609__Gate162->numOfObservedCombs +
	_610__Gate163->numOfObservedCombs +
	_611__Gate164->numOfObservedCombs +
	_612__Gate165->numOfObservedCombs +
	_613__Gate166->numOfObservedCombs +
	_614__Gate167->numOfObservedCombs +
	_615__Gate168->numOfObservedCombs +
	_616__Gate169->numOfObservedCombs +
	_617__Gate170->numOfObservedCombs +
	_618__Gate171->numOfObservedCombs +
	_619__Gate172->numOfObservedCombs +
	_620__Gate173->numOfObservedCombs +
	_621__Gate174->numOfObservedCombs +
	_622__Gate175->numOfObservedCombs +
	_623__Gate176->numOfObservedCombs +
	_624__Gate177->numOfObservedCombs +
	_625__Gate178->numOfObservedCombs +
	_626__Gate179->numOfObservedCombs +
	_627__Gate180->numOfObservedCombs +
	_628__Gate181->numOfObservedCombs +
	_629__Gate182->numOfObservedCombs +
	_630__Gate183->numOfObservedCombs +
	_631__Gate184->numOfObservedCombs +
	_632__Gate185->numOfObservedCombs +
	_633__Gate186->numOfObservedCombs +
	_634__Gate187->numOfObservedCombs +
	_635__Gate188->numOfObservedCombs +
	_636__Gate189->numOfObservedCombs +
	_637__Gate190->numOfObservedCombs +
	_638__Gate191->numOfObservedCombs +
	_639__Gate192->numOfObservedCombs +
	_640__Gate193->numOfObservedCombs +
	_641__Gate194->numOfObservedCombs +
	_642__Gate195->numOfObservedCombs +
	_643__Gate196->numOfObservedCombs +
	_644__Gate197->numOfObservedCombs +
	_645__Gate198->numOfObservedCombs +
	_646__Gate199->numOfObservedCombs +
	_647__Gate200->numOfObservedCombs +
	_648__Gate201->numOfObservedCombs +
	_649__Gate202->numOfObservedCombs +
	_650__Gate203->numOfObservedCombs +
	_651__Gate204->numOfObservedCombs +
	_652__Gate205->numOfObservedCombs +
	_653__Gate206->numOfObservedCombs +
	_654__Gate207->numOfObservedCombs +
	_655__Gate208->numOfObservedCombs +
	_656__Gate209->numOfObservedCombs +
	_657__Gate210->numOfObservedCombs +
	_658__Gate211->numOfObservedCombs +
	_659__Gate212->numOfObservedCombs +
	_660__Gate213->numOfObservedCombs +
	_661__Gate214->numOfObservedCombs +
	_662__Gate215->numOfObservedCombs +
	_663__Gate216->numOfObservedCombs +
	_664__Gate217->numOfObservedCombs +
	_665__Gate218->numOfObservedCombs +
	_666__Gate219->numOfObservedCombs +
	_667__Gate220->numOfObservedCombs +
	_668__Gate221->numOfObservedCombs +
	_669__Gate222->numOfObservedCombs +
	_670__Gate223->numOfObservedCombs +
	_671__Gate224->numOfObservedCombs +
	_672__Gate225->numOfObservedCombs +
	_673__Gate226->numOfObservedCombs +
	_674__Gate227->numOfObservedCombs +
	_675__Gate228->numOfObservedCombs +
	_676__Gate229->numOfObservedCombs +
	_677__Gate230->numOfObservedCombs +
	_678__Gate231->numOfObservedCombs +
	_679__Gate232->numOfObservedCombs +
	_680__Gate233->numOfObservedCombs +
	_681__Gate234->numOfObservedCombs +
	_682__Gate235->numOfObservedCombs +
	_683__Gate236->numOfObservedCombs +
	_684__Gate237->numOfObservedCombs +
	_685__Gate238->numOfObservedCombs +
	_686__Gate239->numOfObservedCombs +
	_687__Gate240->numOfObservedCombs +
	_688__Gate241->numOfObservedCombs +
	_689__Gate242->numOfObservedCombs +
	_690__Gate243->numOfObservedCombs +
	_691__Gate244->numOfObservedCombs +
	_692__Gate245->numOfObservedCombs +
	_693__Gate246->numOfObservedCombs +
	_694__Gate247->numOfObservedCombs +
	_695__Gate248->numOfObservedCombs +
	_696__Gate249->numOfObservedCombs +
	_697__Gate250->numOfObservedCombs +
	_698__Gate251->numOfObservedCombs +
	_699__Gate252->numOfObservedCombs +
	_700__Gate253->numOfObservedCombs +
	_701__Gate254->numOfObservedCombs +
	_702__Gate255->numOfObservedCombs +
	_703__Gate256->numOfObservedCombs;
	cout << "END OF SIM=> Total Observed Combs = " << totalObservedCombs << "\n";
	cout << "GIC Coverage = " << GIC_Coverage << "\n";

}