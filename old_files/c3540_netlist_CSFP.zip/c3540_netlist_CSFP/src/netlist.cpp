#include "netlist.h"
#include <cmath>
std::ofstream GIC_logFile("GIC_logFile.txt");

void c3540_netlist::assignments()
{
	while (true)
	{

		wait();
	}
}

void c3540_netlist::GIC_Coverage_Calculator()
{
	// totalObservedCombs = 0;
	// for ( int i=1; i< numOfGates+1; i++){
	// 	totalObservedCombs += module_map[i]->numOfObservedCombs ;
	// }
	// cout << "END OF SIM=> Total Observed Combs = " << totalObservedCombs << "\n";
	// cout << "GIC Coverage = " << GIC_Coverage << "\n";

}

void c3540_netlist::faultCollection()
{
	if (sc_time_stamp().to_double()>0 ){
		std::vector<std::vector<int>> RX_FAULTS;
		if(N1713.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N1713.read().FAULTS.begin(), N1713.read().FAULTS.end());
		}

		if(N1947.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N1947.read().FAULTS.begin(), N1947.read().FAULTS.end());
		}

		if(N3195.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N3195.read().FAULTS.begin(), N3195.read().FAULTS.end());
		}

		if(N3833.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N3833.read().FAULTS.begin(), N3833.read().FAULTS.end());
		}

		if(N3987.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N3987.read().FAULTS.begin(), N3987.read().FAULTS.end());
		}

		if(N4028.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N4028.read().FAULTS.begin(), N4028.read().FAULTS.end());
		}

		if(N4145.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N4145.read().FAULTS.begin(), N4145.read().FAULTS.end());
		}

		if(N4589.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N4589.read().FAULTS.begin(), N4589.read().FAULTS.end());
		}

		if(N4667.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N4667.read().FAULTS.begin(), N4667.read().FAULTS.end());
		}

		if(N4815.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N4815.read().FAULTS.begin(), N4815.read().FAULTS.end());
		}

		if(N4944.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N4944.read().FAULTS.begin(), N4944.read().FAULTS.end());
		}

		if(N5002.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5002.read().FAULTS.begin(), N5002.read().FAULTS.end());
		}

		if(N5045.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5045.read().FAULTS.begin(), N5045.read().FAULTS.end());
		}

		if(N5047.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5047.read().FAULTS.begin(), N5047.read().FAULTS.end());
		}

		if(N5078.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5078.read().FAULTS.begin(), N5078.read().FAULTS.end());
		}

		if(N5102.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5102.read().FAULTS.begin(), N5102.read().FAULTS.end());
		}

		if(N5120.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5120.read().FAULTS.begin(), N5120.read().FAULTS.end());
		}

		if(N5121.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5121.read().FAULTS.begin(), N5121.read().FAULTS.end());
		}

		if(N5192.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5192.read().FAULTS.begin(), N5192.read().FAULTS.end());
		}

		if(N5231.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5231.read().FAULTS.begin(), N5231.read().FAULTS.end());
		}

		if(N5360.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5360.read().FAULTS.begin(), N5360.read().FAULTS.end());
		}

		if(N5361.read().faulty){
			RX_FAULTS.insert(RX_FAULTS.end(), N5361.read().FAULTS.begin(), N5361.read().FAULTS.end());
		}

		std::sort(RX_FAULTS.begin(), RX_FAULTS.end());
		RX_FAULTS.erase(std::unique(RX_FAULTS.begin(), RX_FAULTS.end()), RX_FAULTS.end());

		det = 0;
		for (std::vector<std::vector<int> >::size_type  j=0; j< RX_FAULTS.size(); j++){
			if (!(std::find(ALL_DET.begin(), ALL_DET.end(), RX_FAULTS[j]) != ALL_DET.end())) 
			{
				module_map[RX_FAULTS[j][0]]->faultIdx = RX_FAULTS[j][1];
				module_map[RX_FAULTS[j][0]]->fault_Detected.notify();
				ALL_DET.push_back(RX_FAULTS[j]);
				det +=1;

			}
		}

		TVnum+=1;
		// cout << "detected faults by TV = " << TVnum <<" is :" <<det <<endl;
		tot_det += det;
		// cout << "detected untill now = " << tot_det<<endl;
		cout << "  Coverage untill now = " << tot_det/3130.0<<endl;	
	}
}
